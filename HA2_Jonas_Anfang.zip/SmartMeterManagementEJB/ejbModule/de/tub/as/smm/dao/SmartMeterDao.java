package de.tub.as.smm.dao;



import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceContext;

import de.tub.as.smm.models.SmartMeter;


@Stateless
public class SmartMeterDao {

	// Injected database connection:
//    @PersistenceContext private EntityManager em;
	
    // Stores a new SmartMeter:
//    public void persist(SmartMeterDao sm) {
//        em.persist(sm);
//    }
//	
    
//	EntityManagerFactory emf = Persistence.createEntityManagerFactory("primary");
//	@PersistenceContext EntityManager em = emf.createEntityManager();
//	EntityTransaction et = null;
	
	/**
	 * Methode schreibt in persistence.xml
	 * @param smd
	 */
	public void persist(SmartMeter smd){
		try{
			EntityManagerFactory emf = Persistence.createEntityManagerFactory("primary");
			EntityManager em = emf.createEntityManager();
			EntityTransaction et = null;
			et = em.getTransaction();
			et.begin();
			em.merge(smd);
			et.commit();
		
		}catch(RuntimeException e){
//			if(et.isActive())
//				et.rollback();
//			throw e;
		}
	}
	
	public SmartMeterDao(){}

} 