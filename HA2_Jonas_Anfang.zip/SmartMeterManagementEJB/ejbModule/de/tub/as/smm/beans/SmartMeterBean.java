package de.tub.as.smm.beans;

import java.io.Serializable;

public class SmartMeterBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -41965973774912648L;
	private String Ger�tekennung;
	private int maxbelastung;
	
	public SmartMeterBean() {
	}
	public SmartMeterBean(String ger�tekennung, int maxbelastung) {
		Ger�tekennung = ger�tekennung;
		this.maxbelastung = maxbelastung;
	}
	public String getGer�tekennung() {
		return Ger�tekennung;
	}
	public void setGer�tekennung(String ger�tekennung) {
		Ger�tekennung = ger�tekennung;
	}
	public int getMaxbelastung() {
		return maxbelastung;
	}
	public void setMaxbelastung(int maxbelastung) {
		this.maxbelastung = maxbelastung;
	}
	

}
