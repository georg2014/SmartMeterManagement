package de.tub.as.smm.beans;

import java.io.Serializable;

public class UserBean implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3828416130429551202L;
	private String userName;
	private String passwort;
	private int userId;
	
	public UserBean(){}

	public UserBean(String userName, String passwort, int userId) {
		super();
		this.userName = userName;
		this.passwort = passwort;
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasswort() {
		return passwort;
	}

	public void setPasswort(String passwort) {
		this.passwort = passwort;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

}
