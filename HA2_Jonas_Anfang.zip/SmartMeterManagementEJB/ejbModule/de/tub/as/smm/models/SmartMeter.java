package de.tub.as.smm.models;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Entity
public class SmartMeter implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// Persistent Fields:
    @Id @GeneratedValue
	private String Ger�tekennung;
	private String maxbelastung;
	
    public SmartMeter(String ger�tekennung, String maxbelastung) {
		Ger�tekennung = ger�tekennung;
		this.maxbelastung = maxbelastung;
	}

	@Override
	public String toString() {
		return "SmartMeter [Ger�tekennung=" + Ger�tekennung + ", maxbelastung=" + maxbelastung + "]";
	}

}
